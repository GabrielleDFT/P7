class FicheUser {
    constructor(userId, nom, prenom, age, photoProfilUrl){
        this.userId = userId;
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.photoProfilUrl = photoProfilUrl;
    }
}

module.exports = FicheUser; 
